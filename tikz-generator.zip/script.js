// global drawing things
let c;
let ctx;

// width and height
let w = 500;
let h = 500;

// grid size
let g = 10;
// quantizing size
let q = 2;

// current placement for placing edges
let vcur = -1;

// current placement for placing ellipses
let ccur = [-1,-1];

// input mode
let mode = 0;

// current graph info (0 = vertices, 1 = edges, 2 = ellipses, 3 = text)
let info = [[],[],[],[]];

function main() {
  c = document.getElementById("canvas");
  ctx = c.getContext("2d");
  c.setAttribute("tabindex", 0);
  drawGrid();

  // allow user input
  c.addEventListener("click", function(e) {
    // get coordinates of click
    let cx = Math.round(e.offsetX/w * g * q) / q;
    let cy = Math.round(e.offsetY/h * g * q) / q;
    if (mode == 0) {
      // check if vertex already exists
      let dup = -1
      for (i = 0; i < info[0].length; i++) {
        if (info[0][i][0] == cx && info[0][i][1] == cy)
          dup = i;
      }
      if (dup != -1) {
        info[0].splice(dup, 1);
        // fix edges being all buggy
        for (i = 0; i < info[1].length; i++) {
          if (info[1][i][0] == dup || info[1][i][1] == dup){
            info[1].splice(i, 1);
            i -= 1;
          }
          else {
            if (info[1][i][0] > dup)
              info[1][i][0] -= 1;
            if (info[1][i][1] > dup)
              info[1][i][1] -= 1;
          }
        }
      } else {
        info[0].push([cx, cy]);
      }
    }
  

    if (mode == 1) {
      // find the closest vertex
      let closeDist = w*w+h*h;
      let closeIndex = -1;
      for (i = 0; i < info[0].length; i++) {
        dist = (cx-info[0][i][0])**2 + (cy-info[0][i][1])**2;
        if (dist < closeDist) {
          closeDist = dist;
          closeIndex = i;
        }
      }

      if (vcur == -1 || closeIndex == -1) vcur = closeIndex;
      else if (vcur != closeIndex) {
        // insert edge
        let dup = -1;
        for (i = 0; i < info[1].length; i++) {
          if ((info[1][i][0] == vcur && info[1][i][1] == closeIndex) || 
             (info[1][i][0] == closeIndex && info[1][i][1] == vcur))
            dup = i;
        }
        if (dup != -1) {
          info[1].splice(dup, 1);
        } else {
          info[1].push([vcur, closeIndex]);
          //console.log(vcur, closeIndex);
        }
        vcur = -1;
      }
      else vcur = -1;
    }

    if (mode == 2) {
      //console.log(ccur, cx, cy);
      if (ccur[0] == -1) ccur = [cx, cy];
      else if (ccur[0] == cx || ccur[1] == cy) ccur = [-1, -1];
      else {
        let dims = [(ccur[0]+cx)/2, (ccur[1]+cy)/2, Math.abs((ccur[0]-cx)/2), Math.abs((ccur[1]-cy)/2)];
        //console.log(dims);
        // check for duplicates
        let dup = -1;
        for (i = 0; i < info[2].length; i++) {
          if (info[2][i][0] == dims[0] && 
             info[2][i][1] == dims[1] && 
             info[2][i][2] == dims[2] && 
             info[2][i][3] == dims[3])
            dup = i;
        }
        if (dup != -1) {
          info[2].splice(dup, 1);
        } else {
          info[2].push(dims);
        }
        
        ccur = [-1, -1];
      }
    }
    
    if (mode == 3) {
      // check if text already exists
      let dup = -1
      for (i = 0; i < info[3].length; i++) {
        if (info[3][i][0] == cx && info[3][i][1] == cy)
          dup = i;
      }
      if (dup != -1) {
        info[3].splice(dup, 1);
      } else {
        info[3].push([cx, cy]);
      }
    }

    
    drawGrid();
  });


  c.addEventListener("keydown", function(e) {
    if (e.key == "v") mode = 0;
    if (e.key == "e") {
       mode = 1;
       vcur = -1;
       drawGrid();
    }
    if (e.key == "c") {
      mode = 2;
      ccur = [-1,-1];
    }
    if (e.key == "t") mode = 3;
  });
}

function drawGrid() {
  // console.log(info);
  ctx.clearRect(0,0,w,h)
  // grid
  ctx.strokeStyle = "lightgray";
  ctx.lineWidth = 2;
  for (let i = 1; i < g; i++) {
    ctx.beginPath();
    ctx.moveTo(0, i*w/g);
    ctx.lineTo(h, i*w/g);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(i*h/g, 0);
    ctx.lineTo(i*h/g, w);
    ctx.stroke();
  }
  // vertices
  ctx.strokeStyle = "black";
  ctx.lineWidth = 2;
  for (let i = 0; i < info[0].length; i++) {
    if (i == vcur) ctx.fillStyle = "red";
    else ctx.fillStyle = "white";
    ctx.beginPath();
    ctx.arc(info[0][i][0]*w/g, info[0][i][1]*h/g, 3, 0, 2 * Math.PI);
    ctx.stroke();
    ctx.fill();
  }

  // edges
  ctx.strokeStyle = "black";
  ctx.lineWidth = 2;
  for (let i = 0; i < info[1].length; i++) {
    let start = info[1][i][0];
    let end = info[1][i][1];
    ctx.beginPath();
    ctx.moveTo(info[0][start][0]*w/g, info[0][start][1]*h/g);
    ctx.lineTo(info[0][end][0]*w/g, info[0][end][1]*h/g);
    ctx.stroke();
    ctx.fill();
  }

  // ellipses
  for (let i = 0; i < info[2].length; i++) {
    ctx.beginPath();
    //console.log(info[2][i][0]*w/g, info[2][i][1]*h/g, info[2][i][2]*h/g, info[2][i][3]*h/g, 0, 0, 2 * Math.PI);
    ctx.ellipse(info[2][i][0]*w/g, info[2][i][1]*h/g, info[2][i][2]*h/g, info[2][i][3]*h/g, 0, 0, 2 * Math.PI);
    ctx.stroke();
  }

  // text
  ctx.fillStyle = "black";
  ctx.font = "20px serif";
  for (let i = 0; i < info[3].length; i++) {
    ctx.fillText(i, info[3][i][0]*w/g-5, info[3][i][1]*w/g+7);
  }




  // SCARY LATEX STUFF
  // HERE BE DRAGONS

  // ellipses
  let element1 = document.getElementById("ellipses");
  let string1 = "";
  for (let i = 0; i < info[2].length; i++) {
    string1 += "\\node[ellipse, fill = white, minimum width = " + (2*info[2][i][2]) + "cm, minimum height = " + (2*info[2][i][3]) + "cm] (c" + i + ") at (" + (info[2][i][0]) + ", " + (g - info[2][i][1]) + ") {}; <br>";
  }
  element1.innerHTML = string1;

  // vertices
  let element2 = document.getElementById("vertices");
  let string2 = "";
  for (let i = 0; i < info[0].length; i++) {
    string2 += "\\node[] (v" + i + ") at (" + info[0][i][0] + "," + (g - info[0][i][1]) + ") {}; <br>";
  }
  element2.innerHTML = string2;

  // edges
  let element3 = document.getElementById("edges");
  let string3 = "";
  for (let i = 0; i < info[1].length; i++) {
    string3 += "\\draw (v" + info[1][i][0] + ")--(v" + info[1][i][1] + "); <br>";
  }
  element3.innerHTML = string3;

  // text
  let element4 = document.getElementById("text");
  let string4 = "";
  for (let i = 0; i < info[3].length; i++) {
    string4 += "\\node[draw=white, fill=white] at (" + info[3][i][0] + "," + (g-info[3][i][1]) + ") {$" + i + "$};<br>";
  }
  element4.innerHTML = string4;
  
  
}

